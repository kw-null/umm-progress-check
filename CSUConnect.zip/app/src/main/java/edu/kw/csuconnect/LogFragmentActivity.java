package edu.kw.csuconnect;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import okhttp3.*;
import okio.*;
import org.java_websocket.*;
import org.json.*;
import org.slf4j.*;

public class LogFragmentActivity extends Fragment {
	
	private List<String> logs;
	private ArrayAdapter<String> adapter;
	
	private LinearLayout linear1;
	private ListView listview1;
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.log_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		this.logs = Debug.getLogs();
		linear1 = _view.findViewById(R.id.linear1);
		listview1 = _view.findViewById(R.id.listview1);
	}
	
	private void initializeLogic() {
		
		
		
		this.adapter = new ArrayAdapter<>(
		requireContext(),
		android.R.layout.simple_list_item_1,
		logs
		);
		listview1.setAdapter(adapter);
	}
	
	public void _RefreshLog(final String _logs) {
		logs.add(0, _logs);
		adapter.notifyDataSetChanged();
	}
	
}