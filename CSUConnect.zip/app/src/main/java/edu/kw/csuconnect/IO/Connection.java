package gnet.io;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import java.net.URI;
import java.nio.ByteBuffer;
import java.util.concurrent.LinkedBlockingQueue;
import edu.kw.csuconnect.Debug;
import java.net.URI;
import gnet.*;

public class Connection extends WebSocketClient {
	private final LinkedBlockingQueue<Octets> receivedProtocols = new LinkedBlockingQueue<>();
	private final Thread receiveThread;
	private volatile boolean running = false;
	private Session session;
	
	public Connection(String host, int port) {
		super(URI.create("wss://" + host + ":" + port));
		this.receiveThread = new Thread(this::processQueue, "ConnectionReceiver");
		this.receiveThread.setDaemon(true);
		try {
			javax.net.ssl.SSLContext sslContext = NetworkUtil.trustAllSSLContext();
			this.setSocketFactory(sslContext.getSocketFactory());
		} catch (Exception e) {
			Debug.Log("ConnectionSSL: " + e.getMessage());
		}
	}
	
	protected void setSession(Session session) {
		this.session = session;
	}
	
	@Override
	public void onOpen(ServerHandshake handshakedata) {
		Debug.Log("[Connection] Connected to server");
		this.running = true;
		this.receiveThread.start();
		if (this.session != null) {
			this.session.onConnect();
		}
	}
	
	@Override
	public void onMessage(ByteBuffer bytes) {
		try {
			byte[] data = new byte[bytes.remaining()];
			bytes.get(data);
			Octets octets = new Octets(data);
			this.receivedProtocols.offer(octets);
		} catch (Exception e) {
			Debug.Log("[Connection] Error parsing buffer: " + e.getMessage());
		}
	}
	
	@Override
	public void onMessage(String message) {
		Debug.Log("[Connection] Message: " + message);
	}
	
	@Override
	public void onClose(int code, String reason, boolean remote) {
		Debug.Log("[Connection] Disconnected: " + reason);
		this.running = false;
		this.receiveThread.interrupt();
		Session s = this.session;
		if (s != null) {
			if (code == 1006) s.onFailed();
			else s.notifyClosed();
		}
		this.setSession(null);
	}
	
	@Override
	public void onError(Exception ex) {
		Debug.Log("[Connection] Error: " + ex.getMessage());
	}
	
	public void process(Octets octets) {
		if (this.isOpen()) {
			this.send(octets.getBytes());
		}
	}
	
	private void processQueue() {
		try {
			while (this.running) {
				Octets os = this.receivedProtocols.take();
				if (this.session != null) {
					this.session.onReceivedOctets(os);
				}
			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		} catch (Exception e) {
			Debug.Log("[Connection] Error in message processing: " + e.getMessage());
		}
	}
}
