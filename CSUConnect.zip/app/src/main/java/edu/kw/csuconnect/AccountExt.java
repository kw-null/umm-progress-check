package edu.kw.csuconnect;

import common.AuthType;
import gnet.command.Authenticate;
import gnet.command.Authenticate_Re;

public final class AccountExt extends ActivityExtension<AccountActivity> {
	private AuthType type; 
	private boolean loading;
	
	public AccountExt(AccountActivity activity) {
		super(activity);
		this.loading = false;
	}
	
	public void Continue(String fullname, String username, String password) {
		if (this.loading) {
			return;
		}
		this.loading = false;
		Authenticate auth = new Authenticate();
		auth.fullname = fullname;
		auth.username = username;
		auth.password = password;
		auth.type = this.getType().value();
		AppClient.Send(auth);
	}
	
	public void setType(AuthType type) {
		this.type = type;
	}
	
	public AuthType getType() {
		return this.type;
	}
	
	public void unload() {
		this.loading = false;
	}
	
	public void _OnProtocol_Authenticate_Re(Authenticate_Re auth) {
		if (super.isActive()) {
			if (auth.code == 0) {
				super.getActivity()._LoginSuccess();
			} else {
				super.getActivity()._onErrorCode(auth.code);
			}
		}
	}
	
	public String _TestLifecycle_() {
		return super.isActive() ? "ACTIVE" : "INACTIVE";
	}
}
