package edu.kw.csuconnect;

import gnet.io.*;
import gnet.*;
import gnet.command.*;

public class AppClient extends Session {
	public static final AppClient Instance = new AppClient();
	private int cache;
	private ProtocolHandler handler;
    
    public void connect() {
        String ip = NetworkUtil.getHostIP();
        if (ip == null) {
            Debug.Log("ip is null!!!");
            return;
        }
        super.tryConnect();
    }
    
	public static void Send(Protocol protocol) {
		if (protocol != null) {
            AppClient client = AppClient.Instance;
			client.send(protocol);
		}
	}
	
	private void send(Protocol protocol) {
		if (protocol.getType() > this.getCache()) {
			Octets octets = protocol.data();
			super.send(octets);
		}
	}
	
	@Override
	protected void onConnect() {
		this.cache = 0;
		this.handler = new ProtocolHandler();
	}
	
	@Override
	protected void onClose() {
        this.cache = 9999;
		this.handler = null;
	}
	
	@Override
	public HandlerStatus onReceivedOctets(Octets octets) {
        if (this.handler != null) {
            return this.handler.process(octets);
        }
		return HandlerStatus.Error;
	}
	
	public void setProtocolCache(int cache) {
		this.cache = cache;
	}
	
	public int getCache() {
		return this.cache;
	}
    
    public void logout() {
        super.stop();
    }
    
    public void checkAlive() {
        KeepAlive ka = (KeepAlive) Protocol.create(500);
        ka.num = this.getCache();
        this.send(ka);
        Debug.Log("KeepAlive: " + ka.num);
    }
}
