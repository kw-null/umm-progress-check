package gnet;

public enum HandlerStatus {
    Success,
    Failed,
    Error;
}