package edu.kw.csuconnect;

import java.util.ArrayList;
import java.util.List;

public final class Debug {
	public static boolean DEBUG_LOGS = true;
    public static boolean DEBUG_VIEW = true;
	private static List<String> logs = new ArrayList<>();
    
	public static void Log(Exception e) {
		if (e != null) {
			Debug.Log("Exception: " + e.getMessage());
		}
	}
	
	public static void Log(String message) {
		if (DEBUG_LOGS && !NullOrEmpty(message)) {
            MainExt me = ActivityExtension.get(MainActivity.class);
            if (me == null) {
                logs.add(0, message);
            } else {
                me.addLog(message);
            }
		}
	}
    
    public static void Log(Object o) {
        if (o != null) {
            Log(String.valueOf(o));
        }
    }
	
	public static void Log(String format, Object... args) {
		if (NullOrEmpty(format)) {
			Debug.Log("format null");
			return;
		}
		Debug.Log(Format(format, args));
	}
	
	private static boolean NullOrEmpty(String message) {
		return message == null && message.trim().equals("");
	}
	
	public static List<String> getLogs() {
		return new ArrayList<>(Debug.logs);
	}
	
	public static String Format(String format, Object... args) {
		if (format == null || format.isEmpty()) {
			return "";
		}
		format = format.replace("{{", "__LEFT_BRACE__").replace("}}", "__RIGHT_BRACE__");
		for (int i = 0; i < args.length; i++) {
			String replacement = String.valueOf(args[i]);
			format = format.replace("{" + i + "}", replacement);
		}
		format = format.replace("__LEFT_BRACE__", "{").replace("__RIGHT_BRACE__", "}");
		return format;
	}
}
