package edu.kw.csuconnect;

import common.FragmentPage;
import java.util.Map;
import java.util.HashMap;
import androidx.fragment.app.Fragment;

public final class MainExt extends ActivityExtension<MainActivity> {
    private final Map<FragmentPage, Fragment> fragments;
    private FragmentPage page; 
	
	public MainExt(MainActivity activity) {
		super(activity);
        fragments = new HashMap<>(4);
        fragments.put(FragmentPage.FORUM, new ForumFragmentActivity());
        fragments.put(FragmentPage.INBOX, new InboxFragmentActivity());
        fragments.put(FragmentPage.PROFILE, new ProfileFragmentActivity());
        fragments.put(FragmentPage.LOGS, new LogFragmentActivity());
	}
	
	public void setPage(FragmentPage page) {
		this.page = page;
	}
	
	public FragmentPage getPage() {
		return this.page;
	}
    
    public Fragment getFragment(FragmentPage page) {
        return this.fragments.get(page);
    }
    
    public Fragment getFragment() {
        return this.fragments.get(this.page);
    }
    
    public void addLog(String message) {
		LogFragmentActivity instance = (LogFragmentActivity) this.getFragment(FragmentPage.LOGS);
		if (instance == null) {
			Debug.Log("RefreshUpdateNew: ForumFragmentActivity or adapter is null");
			return;
		}
		instance.requireActivity().runOnUiThread(() -> {
			instance._RefreshLog(message);
		});
	}
}