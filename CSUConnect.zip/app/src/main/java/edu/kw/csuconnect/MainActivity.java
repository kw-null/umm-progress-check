package edu.kw.csuconnect;

import edu.kw.csuconnect.AccountActivity;
import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.OnAdapterChangeListener;
import androidx.viewpager.widget.ViewPager.OnPageChangeListener;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import okhttp3.*;
import okio.*;
import org.java_websocket.*;
import org.json.*;
import org.slf4j.*;
import common.FragmentPage;

public class MainActivity extends AppCompatActivity {
	
	public MainExt Instance;
	private Typeface INACTIVE;
	private Typeface ACTIVE;
	
	private LinearLayout main;
	private ViewPager viewpager;
	private LinearLayout bottomnavbar;
	private LinearLayout bnv_0;
	private LinearLayout bnv_1;
	private LinearLayout bnv_3;
	private LinearLayout bnv_2;
	private LinearLayout bnv_forum_base;
	private ImageView bnv_forum_icon;
	private TextView bnv_forum_label;
	private LinearLayout bnv_inbox_base;
	private ImageView bnv_inbox_icon;
	private TextView bnv_inbox_label;
	private LinearLayout bnv_profile_base;
	private ImageView bnv_profile_icon;
	private TextView bnv_profile_label;
	private LinearLayout bnv_logs_base;
	private ImageView bnv_logs_icon;
	private TextView bnv_logs_label;
	
	private FragmentAdapterFragmentAdapter FragmentAdapter;
	private Intent intent = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		this.Instance = new MainExt(this);
		this.INACTIVE = Typeface.createFromAsset(getAssets(),"fonts/open_sans.ttf");
		this.ACTIVE = Typeface.createFromAsset(getAssets(),"fonts/open_sans_bold.ttf");
		main = findViewById(R.id.main);
		viewpager = findViewById(R.id.viewpager);
		bottomnavbar = findViewById(R.id.bottomnavbar);
		bnv_0 = findViewById(R.id.bnv_0);
		bnv_1 = findViewById(R.id.bnv_1);
		bnv_3 = findViewById(R.id.bnv_3);
		bnv_2 = findViewById(R.id.bnv_2);
		bnv_forum_base = findViewById(R.id.bnv_forum_base);
		bnv_forum_icon = findViewById(R.id.bnv_forum_icon);
		bnv_forum_label = findViewById(R.id.bnv_forum_label);
		bnv_inbox_base = findViewById(R.id.bnv_inbox_base);
		bnv_inbox_icon = findViewById(R.id.bnv_inbox_icon);
		bnv_inbox_label = findViewById(R.id.bnv_inbox_label);
		bnv_profile_base = findViewById(R.id.bnv_profile_base);
		bnv_profile_icon = findViewById(R.id.bnv_profile_icon);
		bnv_profile_label = findViewById(R.id.bnv_profile_label);
		bnv_logs_base = findViewById(R.id.bnv_logs_base);
		bnv_logs_icon = findViewById(R.id.bnv_logs_icon);
		bnv_logs_label = findViewById(R.id.bnv_logs_label);
		FragmentAdapter = new FragmentAdapterFragmentAdapter(getApplicationContext(), getSupportFragmentManager());
		
		viewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
			@Override
			public void onPageScrolled(int _position, float _positionOffset, int _positionOffsetPixels) {
				
			}
			
			@Override
			public void onPageSelected(int _position) {
				_NavBar(FragmentPage.get(_position));
			}
			
			@Override
			public void onPageScrollStateChanged(int _scrollState) {
				
			}
		});
		
		bnv_forum_base.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_NavBar(FragmentPage.FORUM);
			}
		});
		
		bnv_inbox_base.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_NavBar(FragmentPage.INBOX);
			}
		});
		
		bnv_profile_base.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_NavBar(FragmentPage.PROFILE);
			}
		});
		
		bnv_logs_base.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_NavBar(FragmentPage.LOGS);
			}
		});
	}
	
	private void initializeLogic() {
		
		
		
		
		
		
		FragmentAdapter.setTabCount(4);
		viewpager.setAdapter(FragmentAdapter);
		viewpager.setOffscreenPageLimit((int)4);
		_NavBar(FragmentPage.FORUM);
	}
	
	public class FragmentAdapterFragmentAdapter extends FragmentStatePagerAdapter {
		// This class is deprecated, you should migrate to ViewPager2:
		// https://developer.android.com/reference/androidx/viewpager2/widget/ViewPager2
		Context context;
		int tabCount;
		
		public FragmentAdapterFragmentAdapter(Context context, FragmentManager manager) {
			super(manager);
			this.context = context;
		}
		
		public void setTabCount(int tabCount) {
			this.tabCount = tabCount;
		}
		
		@Override
		public int getCount() {
			return tabCount;
		}
		
		@Override
		public CharSequence getPageTitle(int _position) {
			
			return null;
		}
		
		@Override
		public Fragment getItem(int _position) {
			FragmentPage page = FragmentPage.get(_position);
			if (true) {
				return Instance.getFragment(page);
			}
			return null;
		}
	}
	
	public void _Add(final String _Colour, final ImageView _Imageview) {
		_Imageview.getDrawable().setColorFilter(Color.parseColor(_Colour), PorterDuff.Mode.SRC_IN);
	}
	
	
	public void _NavBar(final FragmentPage _page) {
		Instance.setPage(_page);
		switch(_page) {
			case FORUM: {
				bnv_forum_label.setTypeface(this.ACTIVE, 0);
				bnv_inbox_label.setTypeface(this.INACTIVE, 0);
				bnv_profile_label.setTypeface(this.INACTIVE, 0);
				bnv_logs_label.setTypeface(this.INACTIVE, 0);
				bnv_forum_label.setTextColor(0xFFFFD800);
				bnv_inbox_label.setTextColor(0xFFDCDCDC);
				bnv_profile_label.setTextColor(0xFFDCDCDC);
				bnv_logs_label.setTextColor(0xFFDCDCDC);
				bnv_forum_icon.setImageResource(R.drawable.news_fill);
				bnv_inbox_icon.setImageResource(R.drawable.chat_outline);
				bnv_profile_icon.setImageResource(R.drawable.profile_outline);
				bnv_logs_icon.setImageResource(R.drawable.logs_outline);
				_Add("#FFD800", bnv_forum_icon);
				_Add("#DCDCDC", bnv_inbox_icon);
				_Add("#DCDCDC", bnv_profile_icon);
				_Add("#DCDCDC", bnv_logs_icon);
				break;
			}
			case INBOX: {
				bnv_forum_label.setTypeface(this.INACTIVE, 0);
				bnv_inbox_label.setTypeface(this.ACTIVE, 0);
				bnv_profile_label.setTypeface(this.INACTIVE, 0);
				bnv_logs_label.setTypeface(this.INACTIVE, 0);
				bnv_forum_label.setTextColor(0xFFDCDCDC);
				bnv_inbox_label.setTextColor(0xFFFFD800);
				bnv_profile_label.setTextColor(0xFFDCDCDC);
				bnv_logs_label.setTextColor(0xFFDCDCDC);
				bnv_forum_icon.setImageResource(R.drawable.news_outline);
				bnv_inbox_icon.setImageResource(R.drawable.chat_fill);
				bnv_profile_icon.setImageResource(R.drawable.profile_outline);
				bnv_logs_icon.setImageResource(R.drawable.logs_outline);
				_Add("#DCDCDC", bnv_forum_icon);
				_Add("#FFD800", bnv_inbox_icon);
				_Add("#DCDCDC", bnv_profile_icon);
				_Add("#DCDCDC", bnv_logs_icon);
				break;
			}
			case PROFILE: {
				bnv_forum_label.setTypeface(this.INACTIVE, 0);
				bnv_inbox_label.setTypeface(this.INACTIVE, 0);
				bnv_profile_label.setTypeface(this.ACTIVE, 0);
				bnv_logs_label.setTypeface(this.INACTIVE, 0);
				bnv_forum_label.setTextColor(0xFFDCDCDC);
				bnv_inbox_label.setTextColor(0xFFDCDCDC);
				bnv_profile_label.setTextColor(0xFFFFD800);
				bnv_logs_label.setTextColor(0xFFDCDCDC);
				bnv_forum_icon.setImageResource(R.drawable.news_outline);
				bnv_inbox_icon.setImageResource(R.drawable.chat_outline);
				bnv_profile_icon.setImageResource(R.drawable.profile_fill);
				bnv_logs_icon.setImageResource(R.drawable.logs_outline);
				_Add("#DCDCDC", bnv_forum_icon);
				_Add("#DCDCDC", bnv_inbox_icon);
				_Add("#FFD800", bnv_profile_icon);
				_Add("#DCDCDC", bnv_logs_icon);
				break;
			}
			case LOGS: {
				bnv_forum_label.setTypeface(this.INACTIVE, 0);
				bnv_inbox_label.setTypeface(this.INACTIVE, 0);
				bnv_profile_label.setTypeface(this.INACTIVE, 0);
				bnv_logs_label.setTypeface(this.ACTIVE, 0);
				bnv_forum_label.setTextColor(0xFFDCDCDC);
				bnv_inbox_label.setTextColor(0xFFDCDCDC);
				bnv_profile_label.setTextColor(0xFFDCDCDC);
				bnv_logs_label.setTextColor(0xFFFFD800);
				bnv_forum_icon.setImageResource(R.drawable.news_outline);
				bnv_inbox_icon.setImageResource(R.drawable.chat_outline);
				bnv_profile_icon.setImageResource(R.drawable.profile_outline);
				bnv_logs_icon.setImageResource(R.drawable.logs_fill);
				_Add("#DCDCDC", bnv_forum_icon);
				_Add("#DCDCDC", bnv_inbox_icon);
				_Add("#DCDCDC", bnv_profile_icon);
				_Add("#FFD800", bnv_logs_icon);
				break;
			}
		}
		viewpager.setCurrentItem((int)_page.value());
	}
	
}