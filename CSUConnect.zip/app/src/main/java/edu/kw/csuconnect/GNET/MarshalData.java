package gnet;

public abstract class MarshalData implements Marshal, Cloneable {
    @Override
    public abstract MarshalData clone();
    
    @Override
    public abstract OctetsStream marshal(OctetsStream os);
    
    @Override
    public abstract OctetsStream unmarshal(OctetsStream os);
}