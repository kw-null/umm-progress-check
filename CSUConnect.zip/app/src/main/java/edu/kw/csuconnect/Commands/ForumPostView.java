package gnet.command;

import gnet.*;

public class ForumPostView extends Protocol {
    public String post_id;
    
    public ForumPostView() {
        super(803);
        this.post_id = "";
    }
    
    @Override
    public ForumPostView clone() {
        ForumPostView fpv = new ForumPostView();
        fpv.post_id = this.post_id;
        return fpv;
    }
    
    @Override
    public OctetsStream marshal(OctetsStream os) {
        os.marshal(this.post_id);
        return os;
    }
    
    @Override
    public OctetsStream unmarshal(OctetsStream os) {
        this.post_id = os.String();
        return os;
    }
}