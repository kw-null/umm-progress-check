package edu.kw.csuconnect;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import okhttp3.*;
import okio.*;
import org.java_websocket.*;
import org.json.*;
import org.slf4j.*;
import gnet.command.*;
import gnet.Protocol;
import common.ForumPostData;

public class ForumPostActivity extends AppCompatActivity {
	
	public static ForumPostActivity Instance;
	private long startFetch = 0;
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private TextView textview1;
	private TextView textview2;
	private TextView textview3;
	private TextView textview4;
	private TextView textview5;
	private ImageView imageview1;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.forum_post);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		this.startFetch = System.nanoTime();
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll1 = findViewById(R.id.vscroll1);
		linear1 = findViewById(R.id.linear1);
		textview1 = findViewById(R.id.textview1);
		textview2 = findViewById(R.id.textview2);
		textview3 = findViewById(R.id.textview3);
		textview4 = findViewById(R.id.textview4);
		textview5 = findViewById(R.id.textview5);
		imageview1 = findViewById(R.id.imageview1);
	}
	
	private void initializeLogic() {
		
		if (getIntent().hasExtra("post_id")) {
			String post_id = getIntent().getStringExtra("post_id");
			ForumPostView fpv = new ForumPostView();
			fpv.post_id = post_id;
			AppClient.Send(fpv);
			textview1.setText("Post ID Request: " + post_id);
		}
		
	}
	
	
	@Override
	public void onStop() {
		super.onStop();
		Instance = null;
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		Instance = null;
	}
	
	@Override
	public void onStart() {
		super.onStart();
		Instance = this;
	}
	public void _LoadPost(final Protocol _protocol) {
		runOnUiThread(() -> {
			ForumPostView_Re fpv = (ForumPostView_Re) _protocol;
			ForumPostData post = new ForumPostData(fpv.post);
			setTitle("elapsed time: " + (System.nanoTime() - startFetch) / 1_000_000);
			textview2.setText("Post ID Received: " + post.ID);
			textview3.setText(post.Title);
			textview4.setText(post.Content);
			if (post.Image.length > 0) {
				ImageWebPUtil.byteArrayToImageView(post.Image, imageview1);
				textview5.setText("image bytes[n]: " + post.Image.length);
			}
			else {
				textview5.setVisibility(View.GONE);
				imageview1.setVisibility(View.GONE);
			}
		});
	}
	
}