package edu.kw.csuconnect;

import gnet.*;
import gnet.command.*;
import gnet.rpcdata.*;
import common.*;
import java.util.*;
public class ProtocolHandler {
	private final Map<Integer, Invoke> list;
	
	private interface Invoke {
		HandlerStatus run(Protocol protocol);
	}
	
	public ProtocolHandler() {
		Map<Integer, Invoke> temp = new HashMap<>();
        temp.put(0, this::_OnProtocol_ServerStatus);
        temp.put(25, this::_OnProtocol_ServerSession);
		temp.put(251, this::_OnProtocol_Authenticate_Re);
        temp.put(505, this::_OnProtocol_ProtocolCache);
        temp.put(801, this::_OnProtocol_ForumPostGet_Re);
        temp.put(802, this::_OnProtocol_ForumPostNew);
        temp.put(804, this::_OnProtocol_ForumPostView_Re);
		this.list = Collections.unmodifiableMap(temp);
        RegisterProtocols();
	}
    
    private void RegisterProtocols() {
        Protocol.register(0, new ServerStatus());
        Protocol.register(25, new ServerSession());
        Protocol.register(250, new Authenticate());
        Protocol.register(251, new Authenticate_Re());
        Protocol.register(500, new KeepAlive());
        Protocol.register(505, new ProtocolCache());
        Protocol.register(801, new ForumPostGet_Re());
        Protocol.register(802, new ForumPostNew());
        Protocol.register(803, new ForumPostView());
        Protocol.register(804, new ForumPostView_Re());
    }
	
	public HandlerStatus process(Octets octets) {
		HandlerStatus result = HandlerStatus.Error;
		Protocol protocol = Protocol.unmarshal(octets);
		if (protocol != null) {
			Invoke invoke = this.list.get(protocol.getType());
			if (invoke != null) {
				result = invoke.run(protocol);
			} else {
				Debug.Log("unregistered invoker for type: " + protocol.getType());
				result = HandlerStatus.Failed;
			}
		}
		return result;
	}
	
	private HandlerStatus _OnProtocol_Authenticate_Re(Protocol protocol) {
		Authenticate_Re auth = (Authenticate_Re) protocol;
        AccountExt ext = ActivityExtension.get(AccountActivity.class);
        if (ext != null) {
            ext._OnProtocol_Authenticate_Re(auth);
        }
		return HandlerStatus.Success;
	}
    
    private HandlerStatus _OnProtocol_ServerStatus(Protocol protocol) {
		ServerStatus ss = (ServerStatus) protocol;
        Debug.Log(ss.message, String.valueOf(ss.code));
		return HandlerStatus.Success;
	}
    
    private HandlerStatus _OnProtocol_ServerSession(Protocol protocol) {
		ServerSession ss = (ServerSession) protocol;
        Debug.Log("id: {0} / time: {1} / key: {2}", ss.id, ss.time, ss.key);
		return HandlerStatus.Success;
	}
    
    private HandlerStatus _OnProtocol_ProtocolCache(Protocol protocol) {
		ProtocolCache pc = (ProtocolCache) protocol;
        if (pc.max > AppClient.Instance.getCache()) {
            AppClient.Instance.setProtocolCache(pc.max);
            AppClient.Instance.checkAlive();
        }
		return HandlerStatus.Success;
	}
    
    private HandlerStatus _OnProtocol_ForumPostGet_Re(Protocol protocol) {
		ForumPostGet_Re fpg = (ForumPostGet_Re) protocol;
        if (fpg.posts.size() > 0) {
            ForumPostManager.IsLoaded = fpg.loaded;
            List<ForumPostData> posts = new ArrayList<>();
            for (ForumPost fp : fpg.posts) {
                posts.add(new ForumPostData(fp));
            }
            ForumPostManager.addOldPosts(posts);
            ForumPostManager.IsLoading = false;
        }
		return HandlerStatus.Success;
	}
    
    private HandlerStatus _OnProtocol_ForumPostNew(Protocol protocol) {
		ForumPostNew fpn = (ForumPostNew) protocol;
        ForumPostManager._OnProtocol_ForumPostNew(fpn.post);
		return HandlerStatus.Success;
	}
    
    private HandlerStatus _OnProtocol_ForumPostView_Re(Protocol protocol) {
        ForumPostView_Re fpv = (ForumPostView_Re) protocol;
        if (ForumPostActivity.Instance == null) {
            Debug.Log("ForumPostActivity.Instance == null");
            return HandlerStatus.Failed;
        }
        ForumPostActivity.Instance._LoadPost(protocol);
		return HandlerStatus.Success;
	}
}
