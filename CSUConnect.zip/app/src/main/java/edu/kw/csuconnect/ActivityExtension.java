package edu.kw.csuconnect;

import androidx.annotation.NonNull;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import java.lang.ref.WeakReference;
import java.util.concurrent.ConcurrentHashMap;

public abstract class ActivityExtension<T extends LifecycleOwner> implements DefaultLifecycleObserver {
	private final WeakReference<T> activityRef;
	private boolean isActive;
	
	private static final ConcurrentHashMap<Class<?>, WeakReference<ActivityExtension<?>>> registry = new ConcurrentHashMap<>();
	
	@SuppressWarnings("unchecked")
	protected ActivityExtension(T activity) {
		this.activityRef = new WeakReference<>(activity);
		activity.getLifecycle().addObserver(this);
        Class<?> clazz = (Class<?>) activity.getClass();
        WeakReference<?> wr = new WeakReference<>(this);
		registry.put(clazz, (WeakReference<ActivityExtension<?>>)wr);
	}
	
	public T getActivity() {
		return this.activityRef.get();
	}
	
	public boolean isActive() {
        T activity = this.getActivity();
		return activity != null && this.isActive;
	}
	
	public static <E extends ActivityExtension<?>> E get(Class<?> activityClass) {
		WeakReference<ActivityExtension<?>> ref = registry.get(activityClass);
		return ref != null ? (E) ref.get() : null;
	}
	
	@Override
	public void onCreate(@NonNull LifecycleOwner owner) {}
	
	@Override
	public void onResume(@NonNull LifecycleOwner owner) {}
	
	@Override
	public void onPause(@NonNull LifecycleOwner owner) {}
	
	@Override
	public void onStart(@NonNull LifecycleOwner owner) {
		this.isActive = true;
	}
	
	@Override
	public void onStop(@NonNull LifecycleOwner owner) {
		this.isActive = false;
	}
	@Override
	public void onDestroy(@NonNull LifecycleOwner owner) {
		this.isActive = false;
		this.activityRef.clear();
		registry.remove(owner.getClass());
	}
}
