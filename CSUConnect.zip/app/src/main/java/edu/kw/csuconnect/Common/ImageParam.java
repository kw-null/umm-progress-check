package common;

public enum ImageParam implements EnumUtil.Type<Integer> {
	NULL(0),
    AUTHOR(1),
    PROFILE(2),
    POST(3);
	
	private final int value;
	
	ImageParam(int value) {
		this.value = value;
	}
	
	@Override
	public Integer value() {
		return this.value;
	}
	
	public static ImageParam get(int value) {
		return EnumUtil.fromValue(
		ImageParam.class, 
		value,
		ImageParam.NULL);
	}
}
