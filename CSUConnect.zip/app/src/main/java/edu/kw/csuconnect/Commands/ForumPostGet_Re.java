package gnet.command;

import gnet.*;
import gnet.rpcdata.ForumPost;

public class ForumPostGet_Re extends Protocol {
    public RpcDataVector<ForumPost> posts;
    public boolean loaded;
    
    public ForumPostGet_Re() {
        super(801);
        this.posts = new RpcDataVector<ForumPost>(ForumPost.class);
        this.loaded = false;
    }
    
    @Override
    public ForumPostGet_Re clone() {
        ForumPostGet_Re fpg = new ForumPostGet_Re();
        fpg.posts = this.posts.clone();
        fpg.loaded = this.loaded;
        return fpg;
    }
    
    @Override
    public OctetsStream marshal(OctetsStream os) {
        os.marshal(this.posts);
        os.marshal(this.loaded);
        return os;
    }
    
    @Override
    public OctetsStream unmarshal(OctetsStream os) {
        os.unmarshal(this.posts);
        this.loaded = os.Boolean();
        return os;
    }
}