package gnet.io;

import edu.kw.csuconnect.Debug;
import gnet.*;

public abstract class Session {
	private Connection connection;
	private String host;
	private int port;
	
	protected abstract void onConnect();
	protected abstract void onClose();
	public abstract HandlerStatus onReceivedOctets(Octets octets);
	
	protected void tryConnect(String host, int port) {
		if (this.connection != null) {
			Debug.Log("cannot tryConnect while connected!!!");
			return;
		}
		this.host = host;
		this.port = port;
		this.connection = new Connection(host, port);
		this.connection.setSession(this);
		try {
			this.connection.connectBlocking();
		} catch (InterruptedException e) {
			Debug.Log("[Session] Connect attempt interrupted");
			Thread.currentThread().interrupt();
			this.onFailed();
		}
	}
    
    protected void stop() {
        try {
            if (this.connection != null) {
                this.connection.close();
            } else {
                this.notifyClosed();
            }
        } catch (Exception e) {
            Debug.Log("Session.stop(): " + e.getMessage());
        }
    }
	
	protected void send(Octets octets) {
		if (this.connection != null && this.connection.isOpen()) {
			this.connection.process(octets);
		}
	}
	
	protected void onFailed() {
		Debug.Log("[Session] Connection failed");
		this.clear();
	}
	
	private void clear() {
		this.host = "";
		this.port = 0;
		if (this.connection != null) {
			this.connection.setSession(null);
			this.connection = null;
		}
	}
	
	protected void notifyClosed() {
		Debug.Log("[Session] Connection closed");
		this.onClose();
		this.clear();
	}
	
	protected void tryConnect() {
		new Thread(() -> {
			String info = NetworkUtil.discoverServer(3000);
			if (info == null || !info.startsWith("WS_SERVER:")) {
				Debug.Log("[Session] No server found");
				this.onFailed();
				return;
			}
			String[] parts = info.split(":");
			if (parts.length < 3) {
				Debug.Log("[Session] Invalid server reply: " + info);
				this.onFailed();
				return;
			}
			String host = parts[1];
			int port = Integer.parseInt(parts[2]);
			Debug.Log("[Session] Server " + host + ":" + port);
			this.tryConnect(host, port);
		}).start();
	}
}
