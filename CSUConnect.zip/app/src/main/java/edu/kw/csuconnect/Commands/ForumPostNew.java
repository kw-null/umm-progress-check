package gnet.command;

import gnet.*;
import gnet.rpcdata.ForumPost;

public class ForumPostNew extends Protocol {
    public ForumPost post;
    
    public ForumPostNew() {
        super(802);
        this.post = new ForumPost();
    }
    
    @Override
    public ForumPostNew clone() {
        ForumPostNew fpn = new ForumPostNew();
        fpn.post = this.post.clone();
        return fpn;
    }
    
    @Override
    public OctetsStream marshal(OctetsStream os) {
        os.marshal(this.post);
        return os;
    }
    
    @Override
    public OctetsStream unmarshal(OctetsStream os) {
        os.unmarshal(this.post);
        return os;
    }
}