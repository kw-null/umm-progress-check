package gnet.command;

import gnet.*;

public class ServerSession extends Protocol {
    public int id;
    public String key;
    public long time;
    
    public ServerSession() {
        super(25);
        this.id = 0;
        this.key = "";
        this.time = 0L;
    }
    
    @Override
    public ServerSession clone() {
        ServerSession ss = new ServerSession();
        ss.id = this.id;
        ss.key = this.key;
        ss.time = this.time;
        return ss;
    }
    
    @Override
    public OctetsStream marshal(OctetsStream os) {
        os.marshal(this.id);
        os.marshal(this.key);
        os.marshal(this.time);
        return os;
    }
    
    @Override
    public OctetsStream unmarshal(OctetsStream os) {
        this.id = os.Int();
        this.key = os.String();
        this.time = os.Long();
        return os;
    }
}