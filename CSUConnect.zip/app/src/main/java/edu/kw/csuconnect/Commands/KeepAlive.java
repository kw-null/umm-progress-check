package gnet.command;

import gnet.*;

public class KeepAlive extends Protocol {
    public int num;
    
    public KeepAlive() {
        super(500);
        this.num = 0;
    }
    
    @Override
    public KeepAlive clone() {
        KeepAlive ka = new KeepAlive();
        ka.num = this.num;
        return ka;
    }
    
    @Override
    public OctetsStream marshal(OctetsStream os) {
        os.marshal(this.num);
        return os;
    }
    
    @Override
    public OctetsStream unmarshal(OctetsStream os) {
        this.num = os.Int();
        return os;
    }
}