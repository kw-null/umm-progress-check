package common;

public final class EnumUtil {

    private EnumUtil() {}

    public interface Type<T> {
        T value();
    }

    public static <E extends Enum<E> & Type<T>, T> E fromValue(Class<E> enumClass, T value, E defaultValue) {
        for (E e : enumClass.getEnumConstants()) {
            if (e.value().equals(value)) {
                return e;
            }
        }
        return defaultValue;
    }
}