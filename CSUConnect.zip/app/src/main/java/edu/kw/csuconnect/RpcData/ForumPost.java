package gnet.rpcdata;

import gnet.*;

public class ForumPost extends MarshalData {
    public String id;
    public long time_posted;
    public AuthorInfo author;
    public String title;
    public String content;
    public Octets preview;
    
    public ForumPost() {
        this.id = "";
        this.time_posted = 0L;
        this.author = new AuthorInfo();
        this.title = "";
        this.content = "";
        this.preview = new Octets();
    }
    
    @Override
    public ForumPost clone() {
        ForumPost fp = new ForumPost();
        fp.id = this.id;
        fp.time_posted = this.time_posted;
        fp.author = this.author.clone();
        fp.title = this.title;
        fp.content = this.content;
        fp.preview = this.preview.clone();
        return fp;
    }
    
    @Override
    public OctetsStream marshal(OctetsStream os) {
        os.marshal(this.id);
        os.marshal(this.time_posted);
        os.marshal(this.author);
        os.marshal(this.title);
        os.marshal(this.content);
        os.marshal(this.preview);
        return os;
    }
    
    @Override
    public OctetsStream unmarshal(OctetsStream os) {
        this.id = os.String();
        this.time_posted = os.Long();
        os.unmarshal(this.author);
        this.title = os.String();
        this.content = os.String();
        this.preview = os.Octets();
        return os;
    }
}