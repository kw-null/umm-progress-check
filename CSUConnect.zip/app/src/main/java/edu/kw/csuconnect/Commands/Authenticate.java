package gnet.command;

import gnet.*;

public class Authenticate extends Protocol {
    public String fullname;
    public String username;
    public String password;
    public byte type;
    
    public Authenticate() {
        super(250);
        this.fullname = "";
        this.username = "";
        this.password = "";
        this.type = (byte)0;
    }
    
    @Override
    public Authenticate clone() {
        Authenticate auth = new Authenticate();
        auth.fullname = this.fullname;
        auth.username = this.username;
        auth.password = this.password;
        auth.type = this.type;
        return auth;
    }
    
    @Override
    public OctetsStream marshal(OctetsStream os) {
        os.marshal(this.fullname);
        os.marshal(this.username);
        os.marshal(this.password);
        os.marshal(this.type);
        return os;
    }
    
    @Override
    public OctetsStream unmarshal(OctetsStream os) {
        this.fullname = os.String();
        this.username = os.String();
        this.password = os.String();
        this.type = os.Byte();
        return os;
    }
}