package common;

public enum AuthType implements EnumUtil.Type<Byte> {
	NULL((byte) 0),
	LOGIN((byte) 1),
	REGISTER((byte) 2),
	GUEST_APP((byte) 3),
	GUEST_WEB((byte) 4);
	
	private final byte value;
	
	AuthType(byte value) {
		this.value = value;
	}
	
	@Override
	public Byte value() {
		return this.value;
	}
	
	public static AuthType get(byte value) {
		return EnumUtil.fromValue(
		AuthType.class, 
		value,
		AuthType.NULL);
	}
}
