package edu.kw.csuconnect;

import android.app.Application;
import android.content.Context;

public class CSUCApplication extends Application {
    private static Context context;
    
    @Override
    public void onCreate() {
        super.onCreate();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            Debug.Log("Uncaught Exception in thread " + thread.getName() + ": " + throwable);
        });
        context = this;
    }

    public static Context getContext() {
        return context;
    }
}