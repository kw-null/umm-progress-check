package gnet;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class Octets implements Cloneable {
	private static final Charset TYPE = StandardCharsets.UTF_8;
	private byte[] bytes;
	private int length;
	
	public Octets() {
		this.ensureCapacity(128);
	}
	
	public Octets(int initialCapacity) {
		this.ensureCapacity(initialCapacity);
	}
	
	public Octets(Octets other) {
		this.length = other.length();
		this.bytes = this.allocateBuffer(this.length);
		System.arraycopy(other.bytes, 0, this.bytes, 0, this.length);
	}
	
	public Octets(byte[] byteArray) {
		this.bytes = byteArray;
		this.length = byteArray.length;
	}
	
	public Octets(String str) {
		this.bytes = str.getBytes(Octets.TYPE);
		this.length = bytes.length;
	}
	
	public int length() {
		return this.length;
	}
	
	public byte getByte(int index) {
		return this.bytes[index];
	}
	
	protected Octets appendByte(byte value) {
		this.ensureCapacity(this.length() + 1);
		this.bytes[this.length++] = value;
		return this;
	}
	
	private void ensureCapacity(int requiredLength) {
		if (this.bytes == null) {
			this.bytes = this.allocateBuffer(requiredLength);
		} else if (requiredLength > this.bytes.length) {
			byte[] newBuffer = this.allocateBuffer(requiredLength);
			System.arraycopy(this.bytes, 0, newBuffer, 0, this.length());
			this.bytes = newBuffer;
		}
	}
	
	private byte[] allocateBuffer(int required) {
		int size = 16;
		while (required > size) {
			size <<= 1;
		}
		return new byte[size];
	}
	
	protected Octets insertAt(int index, Octets source) {
		return this.insertBytesAt(index, source.bytes, 0, source.length());
	}
	
	private Octets insertBytesAt(int index, byte[] src, int srcPos, int length) {
		this.ensureCapacity(this.length() + length);
		System.arraycopy(this.bytes, index, this.bytes, index + length, this.length() - index);
		System.arraycopy(src, srcPos, this.bytes, index, length);
		this.length += length;
		return this;
	}
	
	protected byte[] getBytesRange(int offset, int length) {
		byte[] result = new byte[length];
		System.arraycopy(this.bytes, offset, result, 0, length);
		return result;
	}
	
	public boolean isEmpty() {
		int limit = Math.min(this.bytes.length, 128);
		for (int i = 0; i < limit; i++) {
			if (this.bytes[i] != 0) {
				return false;
			}
		}
		return true;
	}
	
	public byte[] getBytes() {
		return this.getBytesRange(0, this.length());
	}
	
	@Override
	public String toString() {
		return new String(this.bytes, 0, this.length, Octets.TYPE);
	}
	
	@Override
	public Octets clone() {
		return new Octets(this);
	}
}
