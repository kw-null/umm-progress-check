package common;

public enum FragmentPage implements EnumUtil.Type<Integer> {
	FORUM(0),
	INBOX(1),
    PROFILE(2),
	LOGS(3);
	
	private final int value;
	
	FragmentPage(int value) {
		this.value = value;
	}
	
	@Override
	public Integer value() {
		return this.value;
	}
	
	public static FragmentPage get(int value) {
		return EnumUtil.fromValue(
		FragmentPage.class, 
		value,
		FragmentPage.LOGS);
	}
}
