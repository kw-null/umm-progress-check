package gnet.command;

import gnet.*;

public class Authenticate_Re extends Protocol {
    public int code;
    public Octets reserved;
    
    public Authenticate_Re() {
        super(251);
        this.code = 101;
        this.reserved = new Octets();
    }
    
    @Override
    public Authenticate_Re clone() {
        Authenticate_Re auth = new Authenticate_Re();
        auth.code = this.code;
        auth.reserved = this.reserved.clone();
        return auth;
    }
    
    @Override
    public OctetsStream marshal(OctetsStream os) {
        os.marshal(this.code);
        os.marshal(this.reserved);
        return os;
    }
    
    @Override
    public OctetsStream unmarshal(OctetsStream os) {
        this.code = os.Int();
        this.reserved = os.Octets();
        return os;
    }
}