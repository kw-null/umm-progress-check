package gnet;

public interface Marshal {
    OctetsStream marshal(OctetsStream os);
    OctetsStream unmarshal(OctetsStream os);
}