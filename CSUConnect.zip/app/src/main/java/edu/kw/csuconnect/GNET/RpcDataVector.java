package gnet;

import java.util.ArrayList;

public class RpcDataVector<T extends MarshalData> extends ArrayList<T> implements Marshal, Cloneable {
    private final Class<T> type;

    public RpcDataVector(Class<T> type) {
        this.type = type;
    }

    @Override
    public RpcDataVector<T> clone() {
        try {
            RpcDataVector<T> cloned = new RpcDataVector<>(this.type);
            for (T item : this) {
                @SuppressWarnings("unchecked")
                T copy = (T) item.clone();
                cloned.add(copy);
            }
            return cloned;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public OctetsStream marshal(OctetsStream os) {
        os.marshal(this.size());
        for (T item : this) {
            item.marshal(os);
        }
        return os;
    }

    @Override
    public OctetsStream unmarshal(OctetsStream os) {
        int count = os.Int();
        for (int i = 0; i < count; i++) {
            try {
                T obj = type.getDeclaredConstructor().newInstance();
                obj.unmarshal(os);
                this.add(obj);
            } catch (Exception e) {
                throw new RuntimeException("Failed to create instance of " + type.getName(), e);
            }
        }
        return os;
    }
}