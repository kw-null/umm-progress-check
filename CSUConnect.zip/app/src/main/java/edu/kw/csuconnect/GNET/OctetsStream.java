package gnet;

public class OctetsStream extends Octets {
    private int position;

    public OctetsStream() {
        super();
    }

    public OctetsStream(int initialCapacity) {
        super(initialCapacity);
    }

    public OctetsStream(Octets source) {
        super(source);
    }

    public OctetsStream marshal(int value) {
        return this.marshal((byte)(value >>> 24))
            .marshal((byte)(value >>> 16))
            .marshal((byte)(value >>> 8))
            .marshal((byte)value);
    }

    public int Int() {
        if (this.position + 4 > super.length()) {
            return 0;
        }
        int b1 = super.getByte(this.position++) & 0xFF;
        int b2 = super.getByte(this.position++) & 0xFF;
        int b3 = super.getByte(this.position++) & 0xFF;
        int b4 = super.getByte(this.position++) & 0xFF;
        return (b1 << 24) | (b2 << 16) | (b3 << 8) | b4;
    }

    public OctetsStream marshal(long value) {
        return this.marshal((byte)(value >>> 56))
            .marshal((byte)(value >>> 48))
            .marshal((byte)(value >>> 40))
            .marshal((byte)(value >>> 32))
            .marshal((byte)(value >>> 24))
            .marshal((byte)(value >>> 16))
            .marshal((byte)(value >>> 8))
            .marshal((byte) value);
    }

    public long Long() {
        if (this.position + 8 > super.length()) {
            return 0L;
        }
        long b1 = super.getByte(this.position++) & 0xFFL;
        long b2 = super.getByte(this.position++) & 0xFFL;
        long b3 = super.getByte(this.position++) & 0xFFL;
        long b4 = super.getByte(this.position++) & 0xFFL;
        long b5 = super.getByte(this.position++) & 0xFFL;
        long b6 = super.getByte(this.position++) & 0xFFL;
        long b7 = super.getByte(this.position++) & 0xFFL;
        long b8 = super.getByte(this.position++) & 0xFFL;
        return (b1 << 56) | (b2 << 48) | (b3 << 40) | (b4 << 32) |
               (b5 << 24) | (b6 << 16) | (b7 << 8) | b8;
    }

    public OctetsStream marshal(Octets source) {
        this.marshal(source.length());
        super.insertAt(this.length(), source);
        return this;
    }

    public Octets Octets() {
        int count = this.Int();
        if (this.position + count > super.length()) {
            return new Octets();
        }
        byte[] data = super.getBytesRange(this.position, count);
        this.position += count;
        return new Octets(data);
    }

    public OctetsStream marshal(byte value) {
        super.appendByte(value);
        return this;
    }

    public byte Byte() {
        if (this.position + 1 > super.length()) {
            return 0;
        }
        return super.getByte(this.position++);
    }

    public OctetsStream marshal(float value) {
        return this.marshal(Float.floatToIntBits(value));
    }

    public float Float() {
        if (this.position + 4 > super.length()) {
            return -1f;
        }
        int bits = this.Int();
        return Float.intBitsToFloat(bits);
    }

    public OctetsStream marshal(double value) {
        return this.marshal(Double.doubleToLongBits(value));
    }

    public double Double() {
        if (this.position + 8 > super.length()) {
            return -1.0;
        }
        long bits = this.Long();
        return Double.longBitsToDouble(bits);
    }

    public OctetsStream marshal(boolean value) {
        return this.marshal((byte)(value ? 1 : 0));
    }

    public boolean Boolean() {
        return this.Byte() == 1;
    }

    public OctetsStream marshal(String value) {
        return this.marshal(new Octets(value));
    }

    public String String() {
        return this.Octets().toString();
    }
    
    public boolean eos() {
        return this.position == super.length();
    }
    
    public void reset() {
        this.position = 0;
    }
    
    public OctetsStream marshal(Marshal marshal) {
        return marshal.marshal(this);
    }
    
    public OctetsStream unmarshal(Marshal marshal) {
        return marshal.unmarshal(this);
    }
}