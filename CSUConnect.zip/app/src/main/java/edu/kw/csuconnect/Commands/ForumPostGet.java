package gnet.command;

import gnet.*;

public class ForumPostGet extends Protocol {
    public int count;
    public long oldest_post;
    
    public ForumPostGet() {
        super(800);
        this.count = 0;
        this.oldest_post = 0L;
    }
    
    @Override
    public ForumPostGet clone() {
        ForumPostGet fpg = new ForumPostGet();
        fpg.count = this.count;
        fpg.oldest_post = this.oldest_post;
        return fpg;
    }
    
    @Override
    public OctetsStream marshal(OctetsStream os) {
        os.marshal(this.count);
        os.marshal(this.oldest_post);
        return os;
    }
    
    @Override
    public OctetsStream unmarshal(OctetsStream os) {
        this.count = os.Int();
        this.oldest_post = os.Long();
        return os;
    }
}