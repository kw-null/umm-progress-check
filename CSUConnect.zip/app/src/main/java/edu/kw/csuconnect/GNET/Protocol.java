package gnet;

import java.util.Map;
import java.util.HashMap;
import edu.kw.csuconnect.Debug;

public abstract class Protocol implements Marshal, Cloneable {
    private static final Map<Integer, Protocol> list = new HashMap<>(10);
    private final int type;
    
    @Override public abstract Protocol clone();
    @Override public abstract OctetsStream marshal(OctetsStream os);
    @Override public abstract OctetsStream unmarshal(OctetsStream os);
    
    public Protocol(int type) {
        this.type = type;
    }
    
    public int getType() {
        return this.type;
    }
    
    public static void register(int type, Protocol protocol) {
        if (type >= 0 && protocol != null) {
            Protocol.list.put(type, protocol);
        }
    }
    
    public static Protocol get(int type) {
        Protocol protocol = null;
        if (list.containsKey(type)) {
            protocol = list.get(type);
        }
        return protocol;
    }
    
    public static Protocol create(int type) {
        Protocol protocol = Protocol.get(type);
        return protocol == null ? null : protocol.clone();
    }
    
    public Octets data() {
        OctetsStream os = new OctetsStream();
        os.marshal(this.getType());
        os.marshal(this);
        return os;
    }
    
    public OctetsStream marshal() {
        OctetsStream os = new OctetsStream();
        os.marshal(this.getType());
        os.marshal(this);
        return os;
    }
    
    public static Protocol unmarshal(Octets o) {
        try {
            OctetsStream os = new OctetsStream(o);
            int type = os.Int();
            Protocol $new = Protocol.create(type);
            if ($new == null) {
                Debug.Log("command invalid type: " + type);
                return null;
            }
            Protocol protocol = $new.clone();
            protocol.unmarshal(os);
            return protocol;
        } catch (Exception ex) {
            Debug.Log("command convert err: " + ex.getMessage());
            return null;
        }
    }
}