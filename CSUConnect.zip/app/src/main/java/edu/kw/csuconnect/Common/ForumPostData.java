package common;

import gnet.rpcdata.ForumPost;
import gnet.rpcdata.AuthorInfo;

public class ForumPostData {
	public String ID;
	public long TimePosted;
	public AuthorInfo Author;
	public String Title;
	public String Content;
    public byte[] Image;
	
	public ForumPostData(ForumPost fp) {
		this.ID = fp.id;
		this.TimePosted = fp.time_posted;
		this.Author = fp.author.clone();
		this.Title = fp.title;
		this.Content = fp.content;
        if (fp.preview.isEmpty()) this.Image = new byte[0];
        else this.Image = fp.preview.clone().getBytes();
	}
}
