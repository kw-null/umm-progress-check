package gnet.io;

import edu.kw.csuconnect.Debug;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SubnetScanner {
    private static final int THREADS = 50;

    public interface Callback {
        void onServerFound(String ip);
        void onNotFound();
    }

    public static void findServerAsync(String myIp, int port, Callback callback) {
        if (myIp == null) {
            callback.onNotFound();
            return;
        }

        String subnet = myIp.substring(0, myIp.lastIndexOf("."));
        ExecutorService executor = Executors.newFixedThreadPool(THREADS);

        executor.execute(() -> {
            try {
                for (int i = 1; i < 255; i++) {
                    final String testIp = subnet + "." + i;
                    try (Socket socket = new Socket()) {
                        socket.connect(new InetSocketAddress(testIp, port), 150);
                        socket.close();
                        executor.shutdownNow();
                        callback.onServerFound(testIp);
                        return;
                    } catch (Exception ignored) {
                    }
                }
            } catch (Exception ignored) {
            }
            executor.shutdown();
            callback.onNotFound();
        });
    }
}