package gnet.command;

import gnet.*;

public class ServerStatus extends Protocol {
    public int code;
    public String message;
    public Octets reserved;
    
    public ServerStatus() {
        super(0);
        this.code = 0;
        this.message = "";
        this.reserved = new Octets();
    }
    
    @Override
    public ServerStatus clone() {
        ServerStatus ss = new ServerStatus();
        ss.code = this.code;
        ss.message = this.message;
        ss.reserved = this.reserved.clone();
        return ss;
    }
    
    @Override
    public OctetsStream marshal(OctetsStream os) {
        os.marshal(this.code);
        os.marshal(this.message);
        os.marshal(this.reserved);
        return os;
    }
    
    @Override
    public OctetsStream unmarshal(OctetsStream os) {
        this.code = os.Int();
        this.message = os.String();
        this.reserved = os.Octets();
        return os;
    }
}