package gnet.command;

import gnet.*;

public class ProtocolCache extends Protocol {
    public int max;
    
    public ProtocolCache() {
        super(505);
        this.max = 0;
    }
    
    @Override
    public ProtocolCache clone() {
        ProtocolCache pc = new ProtocolCache();
        pc.max = this.max;
        return pc;
    }
    
    @Override
    public OctetsStream marshal(OctetsStream os) {
        os.marshal(this.max);
        return os;
    }
    
    @Override
    public OctetsStream unmarshal(OctetsStream os) {
        this.max = os.Int();
        return os;
    }
}