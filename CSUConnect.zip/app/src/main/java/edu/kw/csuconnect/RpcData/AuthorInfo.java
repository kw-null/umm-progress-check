package gnet.rpcdata;

import gnet.*;

public class AuthorInfo extends MarshalData {
    public String id;
    public String name;
    public Octets profile;
    
    public AuthorInfo() {
        this.id = "";
        this.name = "";
        this.profile = new Octets();
    }
    
    @Override
    public AuthorInfo clone() {
        AuthorInfo ai = new AuthorInfo();
        ai.id = this.id;
        ai.name = this.name;
        ai.profile = this.profile.clone();
        return ai;
    }
    
    @Override
    public OctetsStream marshal(OctetsStream os) {
        os.marshal(this.id);
        os.marshal(this.name);
        os.marshal(this.profile);
        return os;
    }
    
    @Override
    public OctetsStream unmarshal(OctetsStream os) {
        this.id = os.String();
        this.name = os.String();
        this.profile = os.Octets();
        return os;
    }
}