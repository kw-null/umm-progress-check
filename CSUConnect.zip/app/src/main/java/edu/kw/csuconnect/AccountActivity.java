package edu.kw.csuconnect;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import okhttp3.*;
import okio.*;
import org.java_websocket.*;
import org.json.*;
import org.slf4j.*;
import common.AuthType;

public class AccountActivity extends AppCompatActivity {
	
	public AccountExt Instance;
	private FloatingActionButton _fab;
	
	private LinearLayout main;
	private LinearLayout logo_name;
	private LinearLayout body;
	private ImageView logo_image;
	private LinearLayout logo_text_body;
	private TextView logo_text_1;
	private TextView logo_text_2;
	private ScrollView body_scroll;
	private LinearLayout body_form;
	private TextView body_title;
	private LinearLayout linear1;
	private LinearLayout input_fullname;
	private LinearLayout input_username;
	private LinearLayout input_password;
	private LinearLayout input_repassword;
	private LinearLayout action_button;
	private LinearLayout divider_or;
	private LinearLayout create_account_body;
	private LinearLayout as_guest_body;
	private TextView textview2;
	private ImageView icon_fullname;
	private EditText text_fullname;
	private ImageView icon_username;
	private EditText text_username;
	private ImageView icon_password;
	private EditText text_password;
	private ImageView icon_repassword;
	private EditText text_repassword;
	private TextView action_button_text;
	private LinearLayout divider_left;
	private TextView divider_text;
	private LinearLayout divider_right;
	private TextView create_account_text;
	private TextView as_guest_text;
	
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.account);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		this.Instance = new AccountExt(this);
		_fab = findViewById(R.id._fab);
		
		main = findViewById(R.id.main);
		logo_name = findViewById(R.id.logo_name);
		body = findViewById(R.id.body);
		logo_image = findViewById(R.id.logo_image);
		logo_text_body = findViewById(R.id.logo_text_body);
		logo_text_1 = findViewById(R.id.logo_text_1);
		logo_text_2 = findViewById(R.id.logo_text_2);
		body_scroll = findViewById(R.id.body_scroll);
		body_form = findViewById(R.id.body_form);
		body_title = findViewById(R.id.body_title);
		linear1 = findViewById(R.id.linear1);
		input_fullname = findViewById(R.id.input_fullname);
		input_username = findViewById(R.id.input_username);
		input_password = findViewById(R.id.input_password);
		input_repassword = findViewById(R.id.input_repassword);
		action_button = findViewById(R.id.action_button);
		divider_or = findViewById(R.id.divider_or);
		create_account_body = findViewById(R.id.create_account_body);
		as_guest_body = findViewById(R.id.as_guest_body);
		textview2 = findViewById(R.id.textview2);
		icon_fullname = findViewById(R.id.icon_fullname);
		text_fullname = findViewById(R.id.text_fullname);
		icon_username = findViewById(R.id.icon_username);
		text_username = findViewById(R.id.text_username);
		icon_password = findViewById(R.id.icon_password);
		text_password = findViewById(R.id.text_password);
		icon_repassword = findViewById(R.id.icon_repassword);
		text_repassword = findViewById(R.id.text_repassword);
		action_button_text = findViewById(R.id.action_button_text);
		divider_left = findViewById(R.id.divider_left);
		divider_text = findViewById(R.id.divider_text);
		divider_right = findViewById(R.id.divider_right);
		create_account_text = findViewById(R.id.create_account_text);
		as_guest_text = findViewById(R.id.as_guest_text);
		
		action_button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				boolean valid = true;
				String fullname = text_fullname.getText().toString().trim();
				String username = text_username.getText().toString().trim();
				String password = text_password.getText().toString();
				String repassword = text_repassword.getText().toString();
				if (Instance.getType() == AuthType.REGISTER) {
					if (fullname.isEmpty()) {
						((EditText)text_fullname).setError("Name is required");
						valid = false;
					}
					else {
						if (!fullname.matches("^(?!\\.)((?!.*\\.\\.)[A-Za-z. ]+)$")) {
							((EditText)text_fullname).setError("Enter a valid full name");
							valid = false;
						}
					}
					if (text_repassword.getText().toString().isEmpty()) {
						((EditText)text_repassword).setError("Password confirmation is required");
						valid = false;
					}
					else {
						if (!password.equals(repassword)) {
							((EditText)text_repassword).setError("Passwords do not match");
							valid = false;
						}
					}
				}
				if (username.isEmpty()) {
					((EditText)text_username).setError("Username is required");
					valid = false;
				}
				else {
					if (!username.matches("^[A-Za-z0-9]+$")) {
						((EditText)text_username).setError("Username must be alphanumeric.");
						valid = false;
					}
				}
				if (password.isEmpty()) {
					((EditText)text_password).setError("Password is required");
					valid = false;
				}
				else {
					if (password.length() < 6) {
						((EditText)text_password).setError("Password length must at least be 6");
						valid = false;
					}
				}
				if (valid) {
					Instance.Continue(fullname, username, password);
				}
			}
		});
		
		create_account_body.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Instance.getType() == AuthType.LOGIN) {
					Instance.setType(AuthType.REGISTER);
					_viewRegister();
				}
				else {
					Instance.setType(AuthType.LOGIN);
					_viewLogin();
				}
			}
		});
		
		as_guest_body.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Instance.setType(AuthType.GUEST_APP);
				Instance.Continue("", "", "");
			}
		});
		
		textview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_LoginSuccess();
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), LogsActivity.class);
				startActivity(i);
			}
		});
	}
	
	private void initializeLogic() {
		// DESIGN
		text_fullname.setTextSize((int)17);
		text_username.setTextSize((int)17);
		text_password.setTextSize((int)17);
		text_repassword.setTextSize((int)17);
		text_repassword.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto.ttf"), 0);
		text_username.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto.ttf"), 0);
		text_password.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto.ttf"), 0);
		text_password.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto.ttf"), 0);
		logo_text_1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_sans_bold.ttf"), 0);
		logo_text_2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_sans_semi.ttf"), 0);
		body_title.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_sans_semi.ttf"), 0);
		divider_text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto.ttf"), 0);
		action_button_text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_sans_semi.ttf"), 1);
		as_guest_text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto.ttf"), 0);
		create_account_text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto.ttf"), 0);
		divider_left.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)50, 0xFF999999));
		divider_right.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)50, 0xFF999999));
		action_button.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)25, 0xFFF6B82D));
		as_guest_body.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)25, 0xFFF4E3C2));
		create_account_body.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)25, (int)8, 0xFF800000, 0xFFFFFBEA));
		input_username.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)25, (int)5, 0xFF660000, 0xFFFDF6E1));
		input_password.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)25, (int)5, 0xFF660000, 0xFFFDF6E1));
		input_fullname.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)25, (int)5, 0xFF660000, 0xFFFDF6E1));
		input_repassword.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)25, (int)5, 0xFF660000, 0xFFFDF6E1));
		body.setBackground(new GradientDrawable() {
			    public GradientDrawable getIns(float radius, int color) {
				        this.setCornerRadii(new float[]{
					            radius, radius,
					            radius, radius,
					            0f, 0f,
					            0f, 0f
					        });
				        this.setColor(color);
				        return this;
				    }
		}.getIns(175f, 0xFFFFFBEA));
		_Add("#660000", icon_username);
		_Add("#660000", icon_password);
		_Add("#660000", icon_fullname);
		_Add("#660000", icon_repassword);
		body.setElevation((float)25);
		input_username.setElevation((float)10);
		input_password.setElevation((float)10);
		input_fullname.setElevation((float)10);
		input_repassword.setElevation((float)10);
		action_button.setElevation((float)10);
		create_account_body.setElevation((float)10);
		as_guest_body.setElevation((float)10);
		text_username.setSingleLine(true);
		text_fullname.setSingleLine(true);
		_removeScollBar(body_scroll);
		// ----- END OF DESIGN
		
		
		this.Instance.setType(AuthType.LOGIN);
		input_fullname.setVisibility(View.GONE);
		input_repassword.setVisibility(View.GONE);
		AppClient.Instance.connect();
	}
	
	public void _Add(final String _Colour, final ImageView _Imageview) {
		_Imageview.getDrawable().setColorFilter(Color.parseColor(_Colour), PorterDuff.Mode.SRC_IN);
	}
	
	
	public void _viewLogin() {
		_TransitionManager(body_form, 350);
		body_title.setText("LOGIN");
		create_account_text.setText("Create an Account");
		input_fullname.setVisibility(View.GONE);
		input_repassword.setVisibility(View.GONE);
	}
	
	
	public void _viewRegister() {
		_TransitionManager(body_form, 350);
		body_title.setText("REGISTER");
		create_account_text.setText("Use Existing Account");
		_SlideAnimation(input_fullname, true, true);
		_SlideAnimation(input_repassword, true, true);
	}
	
	
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	
	public void _SlideAnimation(final View _view, final boolean _visible, final boolean _up) {
		Animation animation;
		if (_visible) {
			    animation = AnimationUtils.loadAnimation(this, _up ? R.anim.slide_in_up : R.anim.slide_in_down);
			    _view.setVisibility(View.VISIBLE);
		} else {
			    animation = AnimationUtils.loadAnimation(this, _up ? R.anim.slide_up : R.anim.slide_down);
			    animation.setAnimationListener(new Animation.AnimationListener() {
				        @Override public void onAnimationStart(Animation animation) {}
				        @Override public void onAnimationRepeat(Animation animation) {}
				        @Override
				        public void onAnimationEnd(Animation animation) {
					            if (_view.getId() == R.id.input_fullname || _view.getId() == R.id.input_repassword)
					            _view.setVisibility(View.GONE);
					        }
				        });
		}
		_view.startAnimation(animation);
	}
	
	
	public void _TransitionManager(final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	public void _LoginSuccess() {
		runOnUiThread(() -> {
			Instance.unload();
			_Custom_Loading(false);
			i.setClass(getApplicationContext(), MainActivity.class);
			startActivity(i);
			finish();
		});
	}
	
	
	public void _onErrorCode(final int _code) {
		runOnUiThread(() -> {
			Instance.unload();
			_Custom_Loading(false);
			String error = "An error occurred.";
			switch((int)_code) {
				case ((int)101): {
					error = "Account Operation Unknown";
					break;
				}
				case ((int)102): {
					error = "Wrong password";
					break;
				}
				case ((int)103): {
					error = "Account does not exist";
					break;
				}
				case ((int)104): {
					error = "Server Type Error";
					break;
				}
				case ((int)105): {
					error = "Username not available";
					break;
				}
				case ((int)106): {
					error = "Username must be alphanumeric";
					break;
				}
				case ((int)107): {
					error = "Empty field";
					break;
				}
				case ((int)108): {
					error = "Password length too short";
					break;
				}
				case ((int)109): {
					error = "Invalid full name";
					break;
				}
				case ((int)110): {
					error = "Server Exception!!!";
					break;
				}
			}
			SketchwareUtil.showMessage(getApplicationContext(), error);
		});
	}
	
	
	public void _Custom_Loading(final boolean _ifShow) {
		if (_ifShow) {
				if (coreprog == null){
						coreprog = new ProgressDialog(this);
						coreprog.setCancelable(false);
						coreprog.setCanceledOnTouchOutside(false);
						coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				}
				coreprog.setMessage(null);
				coreprog.show();
				View _view = getLayoutInflater().inflate(R.layout.loading, null);
				LinearLayout linear_base = (LinearLayout) _view.findViewById(R.id.linear_base);
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
				gd.setColor(Color.parseColor("#800000"));
				gd.setCornerRadius(360);
				linear_base.setBackground(gd);
				coreprog.setContentView(_view);
		}
		else {
				if (coreprog != null){
						coreprog.dismiss();
				}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
}