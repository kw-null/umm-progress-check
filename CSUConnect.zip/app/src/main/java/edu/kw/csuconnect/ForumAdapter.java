package edu.kw.csuconnect;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.ArrayList;
import android.graphics.Typeface;
import common.ForumPostData;
import android.content.Intent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ForumAdapter extends RecyclerView.Adapter<ForumAdapter.ForumViewHolder> {
	
	private final Context context;
	private final List<ForumPostData> postList;
	private final Typeface ROBOTO;
	private final Typeface OPEN_SANS;
	private final Typeface OPEN_SANS_BOLD;
	
	public ForumAdapter(Context context, List<ForumPostData> postList) {
		this.context = context;
		this.postList = (postList != null) ? postList : new ArrayList<>();
		this.ROBOTO = Typeface.createFromAsset(context.getAssets(),"fonts/roboto.ttf");
		this.OPEN_SANS = Typeface.createFromAsset(context.getAssets(),"fonts/open_sans.ttf");
		this.OPEN_SANS_BOLD = Typeface.createFromAsset(context.getAssets(),"fonts/open_sans_bold.ttf");
	}
	
	@NonNull
	@Override
	public ForumViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
		View view = LayoutInflater.from(parent.getContext())
		.inflate(R.layout.post_card, parent, false);
		RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		view.setLayoutParams(_lp);
		return new ForumViewHolder(view);
	}
	
	@Override
	public void onBindViewHolder(@NonNull ForumViewHolder holder, int position) {
		ForumPostData post = postList.get(position);
		holder.bind(post, context, OPEN_SANS, OPEN_SANS_BOLD, ROBOTO);
	}
	
	@Override
	public int getItemCount() {
		return postList != null ? postList.size() : 0;
	}
	
	// ---------------- CRUD METHODS ----------------
	
	/** Update a post at a specific position */
	public void updatePost(int position, ForumPostData newPost) {
		if (position >= 0 && position < postList.size()) {
			postList.set(position, newPost);
			notifyItemChanged(position);
		}
	}
	
	/** Update by ID */
	public void updatePostById(String id, ForumPostData newPost) {
		for (int i = 0; i < postList.size(); i++) {
			if (postList.get(i).ID.equals(id)) {
				this.updatePost(i, newPost);
				break;
			}
		}
	}
	
	/** Add a new post at the top (latest first) */
	public void addNewPost(ForumPostData newPost) {
		postList.add(0, newPost);
		notifyItemInserted(0);
	}
	
	/** Add a batch of older posts at the bottom */
	public void addOlderPosts(List<ForumPostData> olderPosts) {
		int startPos = postList.size();
		postList.addAll(olderPosts);
		notifyItemRangeInserted(startPos, olderPosts.size());
	}
	
	/** Delete a post at a position */
	public void deletePost(int position) {
		if (position >= 0 && position < postList.size()) {
			postList.remove(position);
			notifyItemRemoved(position);
		}
	}
	
	/** Delete by ID */
	public void deletePostById(String id) {
		for (int i = 0; i < postList.size(); i++) {
			if (postList.get(i).ID.equals(id)) {
				this.deletePost(i);
				break;
			}
		}
	}
	
	// ---------------- SCROLL LISTENER (Detect bottom) ----------------
	
	public static void attachScrollListener(RecyclerView recyclerView, final Runnable onBottomReached) {
		recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
			@Override
			public void onScrolled(@NonNull RecyclerView rv, int dx, int dy) {
				super.onScrolled(rv, dx, dy);
				
				RecyclerView.LayoutManager lm = rv.getLayoutManager();
				if (lm instanceof LinearLayoutManager) {
					LinearLayoutManager layoutManager = (LinearLayoutManager) lm;
					int total = layoutManager.getItemCount();
					int lastVisible = layoutManager.findLastVisibleItemPosition();
					
					// near the end? fetch more
					if (lastVisible >= total - 1) {
						if (onBottomReached != null) onBottomReached.run();
					}
				}
			}
		});
	}
	
	// ---------------- ViewHolder ----------------
	
	static class ForumViewHolder extends RecyclerView.ViewHolder {
		final LinearLayout post_card, info, linear1, linear2, header, card_body;
		final CardView cardview1, image_card;
		final ImageView imageview1, imageview2, preview_image;
		final TextView textview1, textview2, textview3, title, content;
		
		ForumViewHolder(@NonNull View _view) {
			super(_view);
			post_card = _view.findViewById(R.id.post_card);
			info = _view.findViewById(R.id.info);
			linear1 = _view.findViewById(R.id.linear1);
			linear2 = _view.findViewById(R.id.linear2);
			header = _view.findViewById(R.id.header);
			card_body = _view.findViewById(R.id.card_body);
			cardview1 = _view.findViewById(R.id.cardview1);
			image_card = _view.findViewById(R.id.image_card);
			imageview1 = _view.findViewById(R.id.imageview1);
			imageview2 = _view.findViewById(R.id.imageview2);
			preview_image = _view.findViewById(R.id.preview_image);
			textview1 = _view.findViewById(R.id.textview1);
			textview2 = _view.findViewById(R.id.textview2);
			textview3 = _view.findViewById(R.id.textview3);
			title = _view.findViewById(R.id.title);
			content = _view.findViewById(R.id.content);
		}
		
		void bind(ForumPostData post, Context context,
		Typeface OPEN_SANS, Typeface OPEN_SANS_BOLD, Typeface ROBOTO) {
			// Fonts
			content.setTypeface(OPEN_SANS, Typeface.NORMAL);
			title.setTypeface(OPEN_SANS_BOLD, Typeface.NORMAL);
			textview1.setTypeface(OPEN_SANS_BOLD, Typeface.NORMAL);
			textview2.setTypeface(ROBOTO, Typeface.NORMAL);
			textview3.setTypeface(ROBOTO, Typeface.BOLD);
			
			// Styles
			post_card.setBackground(new GradientDrawable() {
				public GradientDrawable getIns(int a, int b, int c, int d) {
					this.setCornerRadius(a);
					this.setStroke(b, c);
					this.setColor(d);
					return this;
				}
			}.getIns(10, 3, 0xFF400000, 0xFFFFFBEA));
			
			textview2.setTextSize(10);
			title.setTextSize(20);
			post_card.setElevation(8f);
			
			// Data
			imageview2.setVisibility(View.GONE);
			textview3.setVisibility(View.GONE);
            textview1.setText(post.Author.name);
            if (!post.Author.profile.isEmpty()) {
                ImageWebPUtil.byteArrayToImageView(post.Author.profile.getBytes(), imageview1);
            }
			if (post.Image.length == 0) {
				image_card.setVisibility(View.GONE);
			} else {
				image_card.setVisibility(View.VISIBLE);
				ImageWebPUtil.byteArrayToImageView(post.Image, preview_image);
			}
			title.setText(post.Title);
			content.setText(post.Content);
            SimpleDateFormat sdf = new SimpleDateFormat("MMM d • h:mm a", Locale.ENGLISH);
            textview2.setText(sdf.format(new Date(post.TimePosted)));
			
			post_card.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					Intent intent = new Intent(context, ForumPostActivity.class);
					intent.putExtra("post_id", post.ID);
					context.startActivity(intent);
				}
			});
		}
	}
}
