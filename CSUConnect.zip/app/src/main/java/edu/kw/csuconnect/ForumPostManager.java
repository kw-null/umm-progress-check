package edu.kw.csuconnect;

import common.ForumPostData;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import gnet.command.ForumPostGet;
import gnet.rpcdata.ForumPost;
import common.FragmentPage;
import java.util.ArrayList;
import java.util.List;
import common.ForumPostData;
import gnet.RpcDataVector;

public class ForumPostManager {
	private static  Map<String, ForumPostData> posts = new ConcurrentHashMap<>();
	public static long LatestTime = 0;
	public static long OldestTime = 0;
	public static boolean IsLoaded = false;
	public static boolean IsLoading = false;
	
	public static ArrayList<ForumPostData> getSortedPosts() {
		ArrayList<ForumPostData> list = new ArrayList<>(posts.values());
		list.sort((a, b) -> Long.compare(b.TimePosted, a.TimePosted));
		return list;
	}
	
	public static void fetchPosts(int count) {
		if (IsLoaded || IsLoading) return;
		IsLoading = true;
		ForumPostGet fpg = new ForumPostGet();
		fpg.count = count;
		fpg.oldest_post = OldestTime;
		AppClient.Send(fpg);
	}
	
	public static void _OnProtocol_ForumPostNew(ForumPost post) {
		if (post.time_posted > LatestTime) {
			LatestTime = post.time_posted; 
		}
		boolean isUpdate = posts.containsKey(post.id);
		ForumPostData fp = new ForumPostData(post);
		posts.put(post.id, fp);
		RefreshUpdateNew(fp, isUpdate);
	}
    
    public static void addOldPosts(List<ForumPostData> posts) {
		ForumFragmentActivity instance = getForumInstance();
		if (instance == null || instance.adapter == null) {
			Debug.Log("addOldPosts: ForumFragmentActivity or adapter is null");
			return;
		}
		instance.requireActivity().runOnUiThread(() -> {
			instance.adapter.addOlderPosts(posts);
		});
    }
	
	private static void RefreshUpdateNew(ForumPostData post, boolean old) {
		ForumFragmentActivity instance = getForumInstance();
		if (instance == null || instance.adapter == null) {
			Debug.Log("RefreshUpdateNew: ForumFragmentActivity or adapter is null");
			return;
		}
		instance.requireActivity().runOnUiThread(() -> {
			if (old) instance.adapter.updatePostById(post.ID, post);
			else  instance.adapter.addNewPost(post);
		});
	}
    
    private static ForumFragmentActivity getForumInstance() {
        MainExt me = ActivityExtension.get(MainActivity.class);
		if (me == null) {
			Debug.Log("ForumPostManager: MainExt is null");
			return null;
		}
		ForumFragmentActivity instance = (ForumFragmentActivity) me.getFragment(FragmentPage.FORUM);
		return instance;
    }
}
