package gnet.command;

import gnet.*;
import gnet.rpcdata.ForumPost;

public class ForumPostView_Re extends Protocol {
    public ForumPost post;
    
    public ForumPostView_Re() {
        super(804);
        this.post = new ForumPost();
    }
    
    @Override
    public ForumPostView_Re clone() {
        ForumPostView_Re fpv = new ForumPostView_Re();
        fpv.post = this.post.clone();
        return fpv;
    }
    
    @Override
    public OctetsStream marshal(OctetsStream os) {
        os.marshal(this.post);
        return os;
    }
    
    @Override
    public OctetsStream unmarshal(OctetsStream os) {
        os.unmarshal(this.post);
        return os;
    }
}